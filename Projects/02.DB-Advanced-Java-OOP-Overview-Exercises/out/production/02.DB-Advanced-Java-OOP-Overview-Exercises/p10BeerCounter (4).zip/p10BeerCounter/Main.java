package p10BeerCounter;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String input = reader.readLine();

        while (!"End".equalsIgnoreCase(input)){
            int[] pairOfBeers = Arrays.stream(input.split("\\s+"))
                    .mapToInt(Integer::parseInt)
                    .toArray();
            BeerCounter.buyBeer(pairOfBeers[0]);
            BeerCounter.drinkBeer(pairOfBeers[1]);

            try {
                input = reader.readLine();
            } catch (Exception e) {
                break;
            }
        }

        System.out.println(BeerCounter.getBeerInStock() + " " + BeerCounter.getBeersDrankCount());
    }
}
