package p11OnlineRadioDatabase.exeptions;

public class InvalidSongException extends Throwable {

    public InvalidSongException(String message) {
        super(message);
    }
}
