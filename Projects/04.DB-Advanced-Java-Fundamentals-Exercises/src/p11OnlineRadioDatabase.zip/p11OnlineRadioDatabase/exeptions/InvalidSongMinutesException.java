package p11OnlineRadioDatabase.exeptions;

public class InvalidSongMinutesException extends InvalidSongLengthException {

    public InvalidSongMinutesException(String message) {
        super(message);
    }
}
