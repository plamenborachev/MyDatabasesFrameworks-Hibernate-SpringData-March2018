package p11OnlineRadioDatabase.exeptions;

public class InvalidSongNameException extends InvalidSongException {

    public InvalidSongNameException(String message) {
        super(message);
    }
}
